const form = document.querySelector("form"),
nextBtn = form.querySelector(".sumbitBtn");
// backtBtn = form.querySelector(".backBtn");
allInput =form.querySelectorAll(".firstInput");


nextBtn.addEventListener("click",()=>{
    allInput.forEach(input => {
        if(input.value!=""){
        form.classList.add('secActive');
        }
        else{
            form.classList.remove('secActive'); 
            alert("input is empty")
        }
        
    });
})